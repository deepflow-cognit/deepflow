def main():
    print("- gui deepflow intalled -")