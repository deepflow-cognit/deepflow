def main():
    print("- cli deepflow intalled -")
    